This plugin implements a `graphviz` directive similar to the one in [sphinx](http://sphinx-doc.org/ext/graphviz.html)

The goal is compatibility, although the implementation differs greatly.

It doesn't yet support the alternative ``graph`` and ``digraph`` invocations.

Here's an example of [it's output](http://ralsina.me/weblog/posts/lunchtime-nikola-feature-graphviz.html)
